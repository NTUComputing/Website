using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace _3D_Engine
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Model myModel;
        Model tea;
        Vector3 modelPosition = Vector3.Zero;
        
        Vector3 modelP = new Vector3(0.0f, 40.0f,20.0f);
        
        float z=2000;
        float x=400;
        float y=400;
        float zzoom;
        float aspectRatio;
        float xcam;
        float ycam;
        float zcam;
        Vector3 campos;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Window.Title = "J3D Tester";
            graphics.PreferredBackBufferHeight = 720;
            graphics.PreferredBackBufferWidth = 1280;
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {




            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            myModel = Content.Load<Model>("model");
            tea = Content.Load<Model>("tea");
            aspectRatio = graphics.GraphicsDevice.Viewport.AspectRatio;
        }

        // TODO: use this.Content to load your game content here


        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
    Vector3 modelVelocity = Vector3.Zero;
    

    protected override void Update(GameTime gameTime)
    {
        // Allows the game to exit
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
            this.Exit();
        modelPosition = new Vector3 (x,y,z);
        campos = modelPosition - new Vector3(0,0,40);
        
        // Get some input.
        UpdateInput();

        Updatelogic();

        // Add velocity to the current position.
        modelPosition += modelVelocity;

        // Bleed off velocity over time.
        modelVelocity *= 0.95f;

        base.Update(gameTime);
    }

    protected void UpdateInput()
    {
        zzoom = z - 50;
        KeyboardState keystate = Keyboard.GetState();
        Keyboard.GetState();
        if (keystate.IsKeyDown(Keys.Up))
        {
            y = y - 5.0f; 
        }
        if (keystate.IsKeyDown(Keys.Down))
        {
            y = y + 5.0f;
        }
        if (keystate.IsKeyDown(Keys.Left))
        {
            x = x - 5.0f; 

        }
          if (keystate.IsKeyDown(Keys.Right))
        {
            x = x + 5.0f; 
        }
          if (keystate.IsKeyDown(Keys.A))
          {
              modelRotation = modelRotation - 0.1f;
          }
          if (keystate.IsKeyDown(Keys.D))
          {
              modelRotation = modelRotation + 0.1f;
          }
          if (keystate.IsKeyDown(Keys.W))
          {
              z = z + 10.0f;
          }
          if (keystate.IsKeyDown(Keys.S))
          {
              z = z - 10.0f;
          }
          if (keystate.IsKeyDown(Keys.Escape))
          {
           graphics.ToggleFullScreen();
          }
     
    }

    protected void Updatelogic()
    {

        cameraPosition = modelPosition - new Vector3(x,y,zzoom); 
        
        
        //xcam = modelPosition.X - 60.0f;
        //ycam = modelPosition.Y - 60.0f;
        //zcam = modelPosition.Z - 60.0f;
        //cameraPosition.X = xcam;
        //cameraPosition.Y = ycam;
        //cameraPosition.Z = zcam;
        //base.Update(gameTime);
        //cameraPosition = modelPosition - 60.0f;

    }



        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        /// 
        // Set the position of the model in world space, and set the rotation.
     
        

        
        float modelRotation = 0.0f;
        float modelR = 0.0f;

        // Set the position of the camera in world space, for our view matrix.
        //Vector3 cameraPosition = new Vector3(0.0f, 50.0f, 5000.0f);
        Vector3 cameraPosition =  Vector3.Zero;
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            // Copy any parent transforms.
            Matrix[] transforms = new Matrix[myModel.Bones.Count];
            myModel.CopyAbsoluteBoneTransformsTo(transforms);
            myModel.CopyAbsoluteBoneTransformsTo(transforms);
           
            Matrix[] transform = new Matrix[tea.Bones.Count];
            tea.CopyAbsoluteBoneTransformsTo(transform);
            tea.CopyAbsoluteBoneTransformsTo(transform);

            // Draw the model. A model can have multiple meshes, so loop.
            foreach (ModelMesh mesh in myModel.Meshes)
            {
                // This is where the mesh orientation is set, as well 
                // as our camera and projection.
                foreach (BasicEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.World = transforms[mesh.ParentBone.Index] *
                        Matrix.CreateRotationY(modelRotation)
                        * Matrix.CreateTranslation(modelPosition);
                    effect.View = Matrix.CreateLookAt(cameraPosition, campos, Vector3.Up);
                    
                    effect.Projection = Matrix.CreatePerspectiveFieldOfView(
                        MathHelper.ToRadians(45.0f), aspectRatio,
                        1.0f, 10000.0f);
                }
                // Draw the mesh, using the effects set above.
                mesh.Draw();
            }
            foreach (ModelMesh meshnew in tea.Meshes)
            {
                // This is where the mesh orientation is set, as well 
                // as our camera and projection.
                foreach (BasicEffect effect in meshnew.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.World = transform[meshnew.ParentBone.Index] *
                        Matrix.CreateRotationY(modelR)
                        * Matrix.CreateTranslation(modelP);
                    effect.View = Matrix.CreateLookAt(cameraPosition,
                       campos, Vector3.Up);
                    
                }
                // Draw the mesh, using the effects set above.
                meshnew.Draw();
               
            }
           
        }
    }
}
